# FaultManagement Component — Setup Guide

## Files to copy
- `src/components/FaultManagement.tsx`  → drop into your `src/components/`
- `src/lib/GoogleMapsProvider.tsx`      → drop into your `src/lib/`

## npm packages required
```
pnpm add @react-google-maps/api
```
(or `npm install @react-google-maps/api`)

## Environment variable
Add this to your `.env` (or Replit Secrets):
```
VITE_GOOGLE_MAPS_API_KEY=AIzaSyBimHwfRUw7XWVE4QjFKUbIjm6PaPsEX4M
```

## Wrap your app with the provider (in main.tsx or App.tsx)
```tsx
import { GoogleMapsProvider } from "./lib/GoogleMapsProvider";

<GoogleMapsProvider>
  <App />
</GoogleMapsProvider>
```

## Use the component
```tsx
import { FaultManagement } from "./components/FaultManagement";

<FaultManagement />
```

## API endpoints the component calls (must exist in your backend)
| Method | Path | Description |
|--------|------|-------------|
| GET    | /api/faults/active        | Returns list of ActiveFault objects |
| GET    | /api/faults/:id/trail     | Returns breadcrumb trail points |
| POST   | /api/faults/:id/dispatch  | Auto-dispatches a fault |
| PATCH  | /api/faults/:id/status    | Updates fault status |
| GET    | /api/faults/pbi-status    | Power BI sync status |
| POST   | /api/faults/pbi-sync      | Trigger manual PBI sync |

## ActiveFault shape (from GET /api/faults/active)
```ts
{
  id: number;
  ttId: string;
  cowId: string;
  alarmName: string;
  severity: "critical" | "major" | "minor" | "warning";
  powerSource: string | null;
  backupTime: string | null;
  siteLat: number;
  siteLng: number;
  location: string | null;
  dispatchStatus: "new" | "assigned" | "en_route" | "on_site" | "resolved" | "closed";
  eta: number | null;
  roadEta: number | null;
  distanceKm: number | null;
  routePolyline: { lat: number; lng: number }[] | null;
  receivedAt: string;        // ISO timestamp
  dispatchedAt: string | null;
  movementTriggeredAt: string | null;  // geofence MC departure
  arrivedAt: string | null;            // geofence site arrival
  assignedTechId: number | null;
  assignedTech: string | null;
  techLat: number | null;
  techLng: number | null;
  techArea: string | null;
  techUpdatedAt: string | null;
  techSpeed: number | null;
  techHeading: number | null;
}
```

## TrailPoint shape (from GET /api/faults/:id/trail)
```ts
{ lat: number; lng: number; speed: number | null; heading: number | null; ts: string; }[]
```

## Tailwind CSS
The component uses Tailwind utility classes. Make sure Tailwind is configured in your project.
